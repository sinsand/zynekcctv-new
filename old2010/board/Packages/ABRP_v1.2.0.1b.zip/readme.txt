[size=20pt][color=green][font=times new roman]Anti-Bot Registration Puzzles[/font][/color][/size] [size=14pt][color=orange][font=times new roman]v1.2.0.1b[/font][/color][/size] 
----------------------------------------------------------------------------------------------------------------------------------------------------
[size=0.7em][b]Author:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=143954]Nas[/url]      [b]Original author:[/b] [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=63186]Karl Benson[/url]     [b]Versions: [/b]2.0 RC2, 1.1.x     [b]Available since: [/b]Jan 27 '08     [b]Latest version:[/b] 1.2.0.1b (Jan 1 '10)[/size]

[size=13pt][color=maroon][u][b]Introduction[/b][/u][/color][/size]

This modification adds a randomly chosen simple logic/math puzzle to the Registration page.
They are set at the level Key Stage 2[KS2] (UK) (7-11 year olds).

It is a cat and mouse game between forum software and bot-creators.
We must constantly develop different and unique anti-bot methods to keep our forums as clean as possible.

[size=13pt][color=maroon][u][b]Features[/b][/u][/color][/size]
[size=8pt]
[img]http://forentadatorerna.se/readmes/feature.png[/img] Adds a randomly chosen puzzle
   [img]http://forentadatorerna.se/readmes/subfeature.png[/img] Shapes
   [img]http://forentadatorerna.se/readmes/subfeature.png[/img] Math
   [img]http://forentadatorerna.se/readmes/subfeature.png[/img] Colors
[img]http://forentadatorerna.se/readmes/feature.png[/img] Random tweaks in each puzzle
[img]http://forentadatorerna.se/readmes/feature.png[/img] Random input field
[/size]

[size=13pt][color=maroon][u][b]Changelog[/b][/u][/color][/size]
[code]
1.2.0.1b (1 entry)                                                           January 1 2010
============================================================================================
January 2010
---------------------------------------------------------------------------------
   ! The 1.1.x version wouldn't work (package-info.xml)

1.2.0.1 (2 entries)                                                          January 1 2010
============================================================================================
January 2010
---------------------------------------------------------------------------------
   * Added support for SMF 2.0 RC2 (Tweaks: Register.php, Register.template.php)
   - Removed support for older versions of SMF 2.0.

1.2 (7 entries)                                                              March 18 2008
============================================================================================
April 2009
---------------------------------------------------------------------------------
   $ Taken over by Nas (April 15 '09)
March 2008
---------------------------------------------------------------------------------
   ! Fixed for tabindex
   $ Changed to Show colors + equation in bold (for better reading)
   $ Improved my random input field generator 
   $ Increased size on input box by adding size="30"
   ! Fixed align/valign issue affecting w3c xhtml 1.0 validity
   * Tweaked to get it to work for SMF 2.0 Beta 3 Public

1.1 (2 entries)                                                             February 4 2008
============================================================================================
February 2008
---------------------------------------------------------------------------------
   ! Fixed colors (Thanks AllMassive)
   ! Corrected pentagon string.

1.0 (1 entry)                                                               January 27 2008
============================================================================================
January 2008
---------------------------------------------------------------------------------
   $ Initial release
[/code]