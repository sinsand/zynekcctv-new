[center][color=red][size=24pt]Back to the index[/size][/color]
[url=http://custom.simplemachines.org/mods/index.php?mod=3249]Link to Mod[/url]
[/center]

Settings found in:
[i]Admin[/i] > [i]Configuration[/i] > [i]Modification Settings[/i] > [i]Miscellaneous[/i]

[b]How to install:[/b]
The Package Manager should work in most cases.

[b]Languages:[/b]
- English
- English UTF8
- Dutch
- Dutch UTF8
- Polish (by phantomm)
- Polish UTF8 (also by phantomm)

Translations are welcome!

[b]Features:[/b]
- Admin panel integration
- Custom button name and URL

[b]Changelog:[/b]
0.2:
- Added Polish translation (thanks phantomm!)
- Added option to change menu position (also thanks phantomm!)

0.1:
- Initial release